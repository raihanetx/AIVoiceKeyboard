package com.pixelpro.keyboard.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pixelpro.keyboard.domain.model.*
import com.pixelpro.keyboard.domain.usecase.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class KeyboardViewModel(
    private val getSuggestionsUseCase      : GetSuggestionsUseCase,
    private val getClipboardItemsUseCase   : GetClipboardItemsUseCase,
    private val getCredentialsUseCase      : GetCredentialsUseCase,
    private val saveToCredentialsUseCase   : SaveToCredentialsUseCase,
    private val deleteClipboardItemUseCase : DeleteClipboardItemUseCase,
) : ViewModel() {

    // ── Core keyboard state ──────────────────────────────────────────────────

    private val _state = MutableStateFlow(KeyboardState())
    val state: StateFlow<KeyboardState> = _state.asStateFlow()

    // ── Clipboard & Credentials (stream from repository) ────────────────────

    val clipboardItems: StateFlow<List<ClipboardEntry>> =
        getClipboardItemsUseCase()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val credentials: StateFlow<List<CredentialEntry>> =
        getCredentialsUseCase()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    // ── Typing ───────────────────────────────────────────────────────────────

    fun insert(text: String) {
        _state.update { s ->
            val newBuffer = s.bufferText + text
            val newCaps = if (s.language == KeyboardLanguage.EN && s.isCaps && text.length == 1)
                false else s.isCaps
            val suggestions = computeSuggestions(newBuffer)
            s.copy(bufferText = newBuffer, isCaps = newCaps, suggestions = suggestions)
        }
    }

    fun backspace() {
        _state.update { s ->
            val newBuffer = if (s.bufferText.isNotEmpty()) s.bufferText.dropLast(1) else ""
            s.copy(bufferText = newBuffer, suggestions = computeSuggestions(newBuffer))
        }
    }

    fun usePrediction(word: String) {
        _state.update { s ->
            val buf = s.bufferText
            val newBuf = if (!buf.endsWith(' ') && !buf.endsWith('\n') && buf.isNotEmpty()) {
                val match = Regex("[a-zA-Z]+\$").find(buf)
                val trimmed = if (match != null) buf.dropLast(match.value.length) else buf
                trimmed + word + " "
            } else {
                buf + word + " "
            }
            s.copy(bufferText = newBuf, suggestions = computeSuggestions(newBuf))
        }
    }

    private fun computeSuggestions(buffer: String): List<String> {
        val r = getSuggestionsUseCase(buffer)
        return listOf(r.first, r.second, r.third).filter { it.isNotEmpty() }
    }

    // ── Layout controls ──────────────────────────────────────────────────────

    fun toggleCaps() = _state.update { it.copy(isCaps = !it.isCaps) }

    fun toggleMode() = _state.update {
        it.copy(mode = if (it.mode == KeyboardMode.NUM) KeyboardMode.ALPHA else KeyboardMode.NUM)
    }

    fun swapLanguage() = _state.update {
        it.copy(language = if (it.language == KeyboardLanguage.EN) KeyboardLanguage.BN else KeyboardLanguage.EN,
                mode = KeyboardMode.ALPHA, isCaps = false)
    }

    // ── Overlays ─────────────────────────────────────────────────────────────

    fun showOverlay(type: OverlayType) = _state.update { it.copy(activeOverlay = type) }
    fun hideOverlay() = _state.update { it.copy(activeOverlay = OverlayType.NONE) }

    // ── Voice ────────────────────────────────────────────────────────────────

    fun startVoice() = _state.update {
        it.copy(isVoiceActive = true, voiceLanguage = it.language)
    }

    fun stopVoice() = _state.update { it.copy(isVoiceActive = false) }

    fun toggleVoiceLanguage() = _state.update {
        it.copy(voiceLanguage = if (it.voiceLanguage == KeyboardLanguage.EN)
            KeyboardLanguage.BN else KeyboardLanguage.EN)
    }

    // ── Settings ─────────────────────────────────────────────────────────────

    fun toggleDarkTheme() = _state.update { it.copy(isDarkTheme = !it.isDarkTheme) }
    fun toggleHaptic()    = _state.update { it.copy(isHapticEnabled = !it.isHapticEnabled) }

    // ── Clipboard / Credentials actions ──────────────────────────────────────

    fun pasteFromClipboard(text: String) {
        insert(text)
        hideOverlay()
    }

    fun pasteFromCredential(text: String) {
        insert(text)
        hideOverlay()
    }

    fun saveClipToCredentials(clip: ClipboardEntry) {
        viewModelScope.launch { saveToCredentialsUseCase(clip) }
    }
}
