package com.pixelpro.keyboard.presentation.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pixelpro.keyboard.domain.model.KeyboardLanguage
import com.pixelpro.keyboard.domain.model.OverlayType
import com.pixelpro.keyboard.presentation.theme.KbTheme
import com.pixelpro.keyboard.presentation.theme.PixelProKeyboardTheme
import com.pixelpro.keyboard.presentation.ui.components.*
import com.pixelpro.keyboard.presentation.ui.components.overlays.*
import com.pixelpro.keyboard.presentation.viewmodel.KeyboardViewModel

// ── Root Screen ───────────────────────────────────────────────────────────────

@Composable
fun KeyboardScreen(viewModel: KeyboardViewModel) {
    val state         by viewModel.state.collectAsState()
    val clipboardItems by viewModel.clipboardItems.collectAsState()
    val credentials   by viewModel.credentials.collectAsState()

    PixelProKeyboardTheme(isDark = state.isDarkTheme) {
        val colors = KbTheme.colors

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .background(colors.kbSurface),
        ) {
            // ── Main keyboard body ──────────────────────────────────────────
            Column(modifier = Modifier.fillMaxWidth()) {

                // Top area: toolbar + suggestion bar  (hidden during voice)
                AnimatedVisibility(
                    visible = !state.isVoiceActive,
                    enter   = fadeIn(),
                    exit    = fadeOut(),
                ) {
                    Column {
                        ToolbarRow(
                            onEmojiClick    = { viewModel.showOverlay(OverlayType.EMOJI) },
                            onClipClick     = { viewModel.showOverlay(OverlayType.CLIPBOARD) },
                            onCredClick     = { viewModel.showOverlay(OverlayType.CREDENTIALS) },
                            onLangClick     = { viewModel.swapLanguage() },
                            onSettingsClick = { viewModel.showOverlay(OverlayType.SETTINGS) },
                            onVoiceClick    = { viewModel.startVoice() },
                        )
                        SuggestionBar(
                            suggestions = state.suggestions,
                            onWordClick = { viewModel.usePrediction(it) },
                        )
                    }
                }

                // Inline Voice bar (shown during voice)
                AnimatedVisibility(
                    visible = state.isVoiceActive,
                    enter   = fadeIn() + expandVertically(),
                    exit    = fadeOut() + shrinkVertically(),
                ) {
                    VoiceBar(
                        voiceLang    = state.voiceLanguage,
                        onLangToggle = { viewModel.toggleVoiceLanguage() },
                        onStop       = { viewModel.stopVoice() },
                    )
                }

                // Key Grid
                KeyGrid(
                    language     = state.language,
                    mode         = state.mode,
                    isCaps       = state.isCaps,
                    onChar       = { viewModel.insert(it) },
                    onBackspace  = { viewModel.backspace() },
                    onShift      = { viewModel.toggleCaps() },
                    onModeToggle = { viewModel.toggleMode() },
                    onComma      = { viewModel.insert(",") },
                    onPeriod     = { viewModel.insert(".") },
                    onSpace      = { viewModel.insert(" ") },
                    onEnter      = { viewModel.insert("\n") },
                )
            }

            // ── Overlays (slide up from bottom of keyboard) ─────────────────
            OverlayContainer(
                activeOverlay  = state.activeOverlay,
                clipboardItems = clipboardItems,
                credentials    = credentials,
                isDarkTheme    = state.isDarkTheme,
                isHaptic       = state.isHapticEnabled,
                onBack         = { viewModel.hideOverlay() },
                onPasteClip    = { viewModel.pasteFromClipboard(it) },
                onSaveToCredentials = { viewModel.saveClipToCredentials(it) },
                onPasteCred    = { viewModel.pasteFromCredential(it) },
                onInsertEmoji  = { viewModel.insert(it) },
                onDarkToggle   = { viewModel.toggleDarkTheme() },
                onHapticToggle = { viewModel.toggleHaptic() },
            )
        }
    }
}

// ── Overlay Container ─────────────────────────────────────────────────────────

@Composable
private fun BoxScope.OverlayContainer(
    activeOverlay      : OverlayType,
    clipboardItems     : List<com.pixelpro.keyboard.domain.model.ClipboardEntry>,
    credentials        : List<com.pixelpro.keyboard.domain.model.CredentialEntry>,
    isDarkTheme        : Boolean,
    isHaptic           : Boolean,
    onBack             : () -> Unit,
    onPasteClip        : (String) -> Unit,
    onSaveToCredentials: (com.pixelpro.keyboard.domain.model.ClipboardEntry) -> Unit,
    onPasteCred        : (String) -> Unit,
    onInsertEmoji      : (String) -> Unit,
    onDarkToggle       : () -> Unit,
    onHapticToggle     : () -> Unit,
) {
    val slideSpec = tween<Float>(durationMillis = 300)
    val overlayModifier = Modifier.matchParentSize()

    // Each overlay slides up with translateY(100%) → 0 transition
    AnimatedVisibility(
        visible = activeOverlay == OverlayType.EMOJI,
        enter   = slideInVertically(animationSpec = tween(300)) { it } + fadeIn(),
        exit    = slideOutVertically(animationSpec = tween(300)) { it } + fadeOut(),
        modifier = overlayModifier,
    ) {
        EmojiOverlay(onBack = onBack, onEmoji = onInsertEmoji)
    }

    AnimatedVisibility(
        visible = activeOverlay == OverlayType.CLIPBOARD,
        enter   = slideInVertically(animationSpec = tween(300)) { it } + fadeIn(),
        exit    = slideOutVertically(animationSpec = tween(300)) { it } + fadeOut(),
        modifier = overlayModifier,
    ) {
        ClipboardOverlay(
            items   = clipboardItems,
            onBack  = onBack,
            onPaste = onPasteClip,
            onSave  = onSaveToCredentials,
        )
    }

    AnimatedVisibility(
        visible = activeOverlay == OverlayType.CREDENTIALS,
        enter   = slideInVertically(animationSpec = tween(300)) { it } + fadeIn(),
        exit    = slideOutVertically(animationSpec = tween(300)) { it } + fadeOut(),
        modifier = overlayModifier,
    ) {
        CredentialsOverlay(
            items   = credentials,
            onBack  = onBack,
            onPaste = onPasteCred,
        )
    }

    AnimatedVisibility(
        visible = activeOverlay == OverlayType.SETTINGS,
        enter   = slideInVertically(animationSpec = tween(300)) { it } + fadeIn(),
        exit    = slideOutVertically(animationSpec = tween(300)) { it } + fadeOut(),
        modifier = overlayModifier,
    ) {
        SettingsOverlay(
            isDarkTheme    = isDarkTheme,
            isHaptic       = isHaptic,
            onBack         = onBack,
            onDarkToggle   = onDarkToggle,
            onHapticToggle = onHapticToggle,
        )
    }
}
