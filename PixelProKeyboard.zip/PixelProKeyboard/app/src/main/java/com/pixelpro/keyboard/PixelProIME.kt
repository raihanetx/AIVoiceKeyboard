package com.pixelpro.keyboard

import android.inputmethodservice.InputMethodService
import android.view.View
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.*
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import com.pixelpro.keyboard.di.AppModule
import com.pixelpro.keyboard.presentation.ui.KeyboardScreen

/**
 * The InputMethodService that hosts the full Compose keyboard UI.
 *
 * Because an IME is not a ComponentActivity, we need to manually
 * implement LifecycleOwner + SavedStateRegistryOwner so that
 * ComposeView / ViewModel machinery works correctly.
 */
class PixelProIME :
    InputMethodService(),
    LifecycleOwner,
    ViewModelStoreOwner,
    SavedStateRegistryOwner {

    // ── Lifecycle ──────────────────────────────────────────────────────────

    private val lifecycleRegistry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry

    // ── ViewModelStore ─────────────────────────────────────────────────────

    private val store = ViewModelStore()
    override val viewModelStore: ViewModelStore get() = store

    // ── SavedStateRegistry ─────────────────────────────────────────────────

    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry

    // ── ViewModel (provided by DI module) ─────────────────────────────────

    private val viewModel by lazy { AppModule.provideKeyboardViewModel() }

    // ── IME lifecycle ──────────────────────────────────────────────────────

    override fun onCreate() {
        savedStateRegistryController.performAttach()
        savedStateRegistryController.performRestore(null)
        super.onCreate()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
    }

    override fun onCreateInputView(): View {
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        return ComposeView(this).apply {
            // Required so ComposeView can resolve LocalLifecycleOwner etc.
            setViewCompositionStrategy(
                androidx.compose.ui.platform.ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed
            )
            setContent {
                KeyboardScreen(viewModel = viewModel)
            }
        }
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()
    }
}
