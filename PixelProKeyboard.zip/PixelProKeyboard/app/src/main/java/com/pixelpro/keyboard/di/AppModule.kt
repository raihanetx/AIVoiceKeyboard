package com.pixelpro.keyboard.di

import com.pixelpro.keyboard.data.repository.ClipboardRepositoryImpl
import com.pixelpro.keyboard.data.repository.CredentialRepositoryImpl
import com.pixelpro.keyboard.data.repository.SuggestionRepositoryImpl
import com.pixelpro.keyboard.domain.repository.ClipboardRepository
import com.pixelpro.keyboard.domain.repository.CredentialRepository
import com.pixelpro.keyboard.domain.repository.SuggestionRepository
import com.pixelpro.keyboard.domain.usecase.*
import com.pixelpro.keyboard.presentation.viewmodel.KeyboardViewModel

/**
 * Manual DI container (replace with Hilt/Koin if preferred).
 * Single object so repositories share the same instance across the app.
 */
object AppModule {

    private val suggestionRepository: SuggestionRepository by lazy {
        SuggestionRepositoryImpl()
    }
    private val clipboardRepository: ClipboardRepository by lazy {
        ClipboardRepositoryImpl()
    }
    private val credentialRepository: CredentialRepository by lazy {
        CredentialRepositoryImpl()
    }

    private val getSuggestionsUseCase   by lazy { GetSuggestionsUseCase(suggestionRepository) }
    private val getClipboardItemsUseCase by lazy { GetClipboardItemsUseCase(clipboardRepository) }
    private val getCredentialsUseCase   by lazy { GetCredentialsUseCase(credentialRepository) }
    private val saveToCredentialsUseCase by lazy {
        SaveToCredentialsUseCase(clipboardRepository, credentialRepository)
    }
    private val deleteClipboardItemUseCase by lazy {
        DeleteClipboardItemUseCase(clipboardRepository)
    }

    fun provideKeyboardViewModel() = KeyboardViewModel(
        getSuggestionsUseCase      = getSuggestionsUseCase,
        getClipboardItemsUseCase   = getClipboardItemsUseCase,
        getCredentialsUseCase      = getCredentialsUseCase,
        saveToCredentialsUseCase   = saveToCredentialsUseCase,
        deleteClipboardItemUseCase = deleteClipboardItemUseCase,
    )
}
