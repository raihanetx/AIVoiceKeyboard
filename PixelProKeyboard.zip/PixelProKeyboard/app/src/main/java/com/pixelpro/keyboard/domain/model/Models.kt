package com.pixelpro.keyboard.domain.model

// ── Keyboard State ──────────────────────────────────────────────────────────

enum class KeyboardLanguage { EN, BN }
enum class KeyboardMode    { ALPHA, NUM }

data class KeyboardState(
    val language: KeyboardLanguage = KeyboardLanguage.EN,
    val mode: KeyboardMode = KeyboardMode.ALPHA,
    val isCaps: Boolean = false,
    val bufferText: String = "",
    val isDarkTheme: Boolean = false,
    val isHapticEnabled: Boolean = true,
    val activeOverlay: OverlayType = OverlayType.NONE,
    val isVoiceActive: Boolean = false,
    val voiceLanguage: KeyboardLanguage = KeyboardLanguage.EN,
    val suggestions: List<String> = emptyList(),
)

enum class OverlayType { NONE, EMOJI, CLIPBOARD, CREDENTIALS, SETTINGS }

// ── Clipboard ───────────────────────────────────────────────────────────────

data class ClipboardEntry(
    val id: String,
    val text: String,
    val timestamp: Long,
    val timeLabel: String,   // "10 mins ago"
    val iconType: ClipIconType = ClipIconType.HISTORY,
)

enum class ClipIconType { HISTORY, LINK, TEXT }

// ── Credentials ─────────────────────────────────────────────────────────────

data class CredentialEntry(
    val id: String,
    val text: String,
    val label: String,   // "Saved Item"
    val iconType: CredIconType = CredIconType.LOCK,
)

enum class CredIconType { LOCK, PHONE, EMAIL }

// ── Suggestions ─────────────────────────────────────────────────────────────

data class SuggestionResult(
    val first: String,
    val second: String,
    val third: String,
)
