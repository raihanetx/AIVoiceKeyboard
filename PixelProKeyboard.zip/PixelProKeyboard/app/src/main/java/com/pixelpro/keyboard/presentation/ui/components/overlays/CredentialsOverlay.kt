package com.pixelpro.keyboard.presentation.ui.components.overlays

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material.icons.outlined.Email
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pixelpro.keyboard.domain.model.CredIconType
import com.pixelpro.keyboard.domain.model.CredentialEntry
import com.pixelpro.keyboard.presentation.theme.KbTheme

@Composable
fun CredentialsOverlay(
    items   : List<CredentialEntry>,
    onBack  : () -> Unit,
    onPaste : (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = KbTheme.colors

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colors.kbSurface),
    ) {
        OverlayHeader(title = "Credentials", onBack = onBack)

        LazyColumn(
            modifier            = Modifier.fillMaxSize(),
            contentPadding      = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(items, key = { it.id }) { entry ->
                val icon = when (entry.iconType) {
                    CredIconType.LOCK  -> Icons.Outlined.Lock
                    CredIconType.PHONE -> Icons.Outlined.Phone
                    CredIconType.EMAIL -> Icons.Outlined.Email
                }
                ListTile(
                    icon     = icon,
                    iconTint = colors.accent,
                    iconBg   = colors.accentSoft,
                    title    = entry.text,
                    subtitle = entry.label,
                    onClick  = { onPaste(entry.text) },
                )
            }
        }
    }
}
