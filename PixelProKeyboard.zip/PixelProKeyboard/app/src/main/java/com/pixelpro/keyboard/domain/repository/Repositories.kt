package com.pixelpro.keyboard.domain.repository

import com.pixelpro.keyboard.domain.model.ClipboardEntry
import com.pixelpro.keyboard.domain.model.CredentialEntry
import com.pixelpro.keyboard.domain.model.SuggestionResult
import kotlinx.coroutines.flow.Flow

interface SuggestionRepository {
    fun getSuggestions(bufferText: String): SuggestionResult
}

interface ClipboardRepository {
    fun getClipboardItems(): Flow<List<ClipboardEntry>>
    suspend fun removeItem(id: String)
    suspend fun addItem(entry: ClipboardEntry)
}

interface CredentialRepository {
    fun getCredentials(): Flow<List<CredentialEntry>>
    suspend fun addCredential(entry: CredentialEntry)
    suspend fun removeCredential(id: String)
}
