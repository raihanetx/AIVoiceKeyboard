package com.pixelpro.keyboard.data.repository

import com.pixelpro.keyboard.data.source.Dictionary
import com.pixelpro.keyboard.domain.model.*
import com.pixelpro.keyboard.domain.repository.ClipboardRepository
import com.pixelpro.keyboard.domain.repository.CredentialRepository
import com.pixelpro.keyboard.domain.repository.SuggestionRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID

// ── Suggestion ───────────────────────────────────────────────────────────────

class SuggestionRepositoryImpl : SuggestionRepository {
    override fun getSuggestions(bufferText: String): SuggestionResult {
        val text = bufferText
        if (text.trim().isEmpty()) return SuggestionResult("","","")

        val isTrailingSpace = text.endsWith(' ') || text.endsWith('\n')
        val words = text.trimEnd().split(Regex("[\\s\n]+"))
        val currentWord = if (isTrailingSpace) "" else words.lastOrNull() ?: ""
        val prevWord = if (words.size > 1) words[words.size - 2].lowercase()
                       else if (words.size == 1 && currentWord.isEmpty()) words[0].lowercase()
                       else ""

        val suggestions: List<String> = if (currentWord.isNotEmpty()) {
            Dictionary.words.filter { it.startsWith(currentWord.lowercase()) && it != currentWord.lowercase() }
                .take(3).ifEmpty { Dictionary.generic }
        } else {
            (Dictionary.nextWordMap[prevWord] ?: Dictionary.generic)
        }

        return SuggestionResult(
            first  = suggestions.getOrElse(0) { "" },
            second = suggestions.getOrElse(1) { "" },
            third  = suggestions.getOrElse(2) { "" },
        )
    }
}

// ── Clipboard ────────────────────────────────────────────────────────────────

class ClipboardRepositoryImpl : ClipboardRepository {
    private val _items = MutableStateFlow(
        listOf(
            ClipboardEntry("c1","Sounds good, let me know.", System.currentTimeMillis(), "10 mins ago", ClipIconType.HISTORY),
            ClipboardEntry("c2","https://google.com",        System.currentTimeMillis(), "1 hour ago",  ClipIconType.LINK),
        )
    )

    override fun getClipboardItems(): Flow<List<ClipboardEntry>> = _items.asStateFlow()

    override suspend fun removeItem(id: String) {
        _items.update { list -> list.filterNot { it.id == id } }
    }

    override suspend fun addItem(entry: ClipboardEntry) {
        _items.update { list -> listOf(entry) + list }
    }
}

// ── Credentials ──────────────────────────────────────────────────────────────

class CredentialRepositoryImpl : CredentialRepository {
    private val _items = MutableStateFlow(
        listOf(
            CredentialEntry("cr1","contact@design.io","Saved Pin", CredIconType.LOCK),
            CredentialEntry("cr2","123-456-7890",     "Saved Pin", CredIconType.PHONE),
        )
    )

    override fun getCredentials(): Flow<List<CredentialEntry>> = _items.asStateFlow()

    override suspend fun addCredential(entry: CredentialEntry) {
        _items.update { list -> listOf(entry) + list }
    }

    override suspend fun removeCredential(id: String) {
        _items.update { list -> list.filterNot { it.id == id } }
    }
}
