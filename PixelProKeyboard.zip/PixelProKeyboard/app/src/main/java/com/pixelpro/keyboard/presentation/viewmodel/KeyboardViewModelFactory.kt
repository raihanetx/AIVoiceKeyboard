package com.pixelpro.keyboard.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.pixelpro.keyboard.domain.usecase.*

/**
 * Manual ViewModelProvider.Factory — use this if you wire the ViewModel
 * inside an Activity or Fragment instead of the IME service directly.
 *
 * In [com.pixelpro.keyboard.PixelProIME] we instantiate the ViewModel
 * lazily via [com.pixelpro.keyboard.di.AppModule], so this factory is
 * provided for completeness and future use (e.g. Hilt migration).
 */
class KeyboardViewModelFactory(
    private val getSuggestionsUseCase      : GetSuggestionsUseCase,
    private val getClipboardItemsUseCase   : GetClipboardItemsUseCase,
    private val getCredentialsUseCase      : GetCredentialsUseCase,
    private val saveToCredentialsUseCase   : SaveToCredentialsUseCase,
    private val deleteClipboardItemUseCase : DeleteClipboardItemUseCase,
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(KeyboardViewModel::class.java)) {
            return KeyboardViewModel(
                getSuggestionsUseCase      = getSuggestionsUseCase,
                getClipboardItemsUseCase   = getClipboardItemsUseCase,
                getCredentialsUseCase      = getCredentialsUseCase,
                saveToCredentialsUseCase   = saveToCredentialsUseCase,
                deleteClipboardItemUseCase = deleteClipboardItemUseCase,
            ) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
