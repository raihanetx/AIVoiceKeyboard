package com.pixelpro.keyboard.presentation.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.pixelpro.keyboard.domain.model.KeyboardLanguage
import com.pixelpro.keyboard.presentation.theme.KbTheme
import com.pixelpro.keyboard.presentation.theme.KbType
import com.pixelpro.keyboard.presentation.theme.Palette

// ── Inline Voice Bar ──────────────────────────────────────────────────────────

@Composable
fun VoiceBar(
    voiceLang   : KeyboardLanguage,
    onLangToggle: () -> Unit,
    onStop      : () -> Unit,
    modifier    : Modifier = Modifier,
) {
    val colors = KbTheme.colors

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(48.dp)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        // Language pill
        val langLabel = if (voiceLang == KeyboardLanguage.EN) "English" else "বাংলা"
        LangPill(label = langLabel, onClick = onLangToggle)

        // Animated visualizer
        Spacer(Modifier.weight(1f))
        AudioVisualizer(
            accentColor = colors.accent,
            modifier    = Modifier.weight(1f),
        )
        Spacer(Modifier.weight(1f))

        // Stop button
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Palette.ErrorRed)
                .clickable(onClick = onStop),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector        = Icons.Outlined.Stop,
                contentDescription = "Stop voice",
                tint               = Color.White,
                modifier           = Modifier.size(16.dp),
            )
        }
    }
}

@Composable
private fun LangPill(label: String, onClick: () -> Unit) {
    val colors = KbTheme.colors
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(colors.specialBg)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(
            imageVector        = Icons.Outlined.Language,
            contentDescription = null,
            tint               = colors.keyText,
            modifier           = Modifier.size(14.dp),
        )
        Text(text = label, style = KbType.voiceLang, color = colors.keyText)
    }
}

// ── Audio Visualizer (5 animated bars) ───────────────────────────────────────

private val barDelays = listOf(0, 200, 400, 100, 300)

@Composable
private fun AudioVisualizer(accentColor: Color, modifier: Modifier = Modifier) {
    Row(
        modifier            = modifier.height(40.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment   = Alignment.CenterVertically,
    ) {
        repeat(5) { index ->
            AnimatedBar(accentColor = accentColor, delayMs = barDelays[index])
        }
    }
}

@Composable
private fun AnimatedBar(accentColor: Color, delayMs: Int) {
    val infiniteTransition = rememberInfiniteTransition(label = "bar")
    val height by infiniteTransition.animateFloat(
        initialValue = 6f,
        targetValue  = 28f,
        animationSpec = infiniteRepeatable(
            animation  = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
            initialStartOffset = StartOffset(delayMs),
        ),
        label = "barHeight",
    )
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue  = 1f,
        animationSpec = infiniteRepeatable(
            animation  = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
            initialStartOffset = StartOffset(delayMs),
        ),
        label = "barAlpha",
    )
    Box(
        modifier = Modifier
            .width(3.dp)
            .height(height.dp)
            .clip(RoundedCornerShape(2.dp))
            .background(accentColor.copy(alpha = alpha))
    )
}
