package com.pixelpro.keyboard.presentation.ui.components.overlays

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.pixelpro.keyboard.presentation.theme.KbTheme
import com.pixelpro.keyboard.presentation.theme.KbType

@Composable
fun SettingsOverlay(
    isDarkTheme    : Boolean,
    isHaptic       : Boolean,
    onBack         : () -> Unit,
    onDarkToggle   : () -> Unit,
    onHapticToggle : () -> Unit,
    modifier       : Modifier = Modifier,
) {
    val colors = KbTheme.colors

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colors.kbSurface),
    ) {
        OverlayHeader(title = "Settings", onBack = onBack)

        LazyColumn(
            modifier       = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        ) {
            item { SettingsGroupTitle("Preferences") }

            item {
                Spacer(Modifier.height(4.dp))
                SettingsToggleRow(
                    label    = "Dark Mode",
                    checked  = isDarkTheme,
                    onToggle = onDarkToggle,
                )
            }
            item {
                Spacer(Modifier.height(8.dp))
                SettingsToggleRow(
                    label    = "Haptic Feedback",
                    checked  = isHaptic,
                    onToggle = onHapticToggle,
                )
            }

            item { SettingsGroupTitle("Voice Input") }

            item {
                Spacer(Modifier.height(4.dp))
                SettingsSelectRow(label = "English Engine", options = listOf("Android Offline","Groq System"))
            }
            item {
                Spacer(Modifier.height(8.dp))
                SettingsSelectRow(label = "Bengali Engine", options = listOf("Android Offline","Groq System"))
            }
        }
    }
}

// ── Toggle Row ────────────────────────────────────────────────────────────────

@Composable
private fun SettingsToggleRow(label: String, checked: Boolean, onToggle: () -> Unit) {
    val colors = KbTheme.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(colors.keyBg)
            .padding(horizontal = 16.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(text = label, style = KbType.tileText, color = colors.keyText)
        Switch(
            checked         = checked,
            onCheckedChange = { onToggle() },
            colors          = SwitchDefaults.colors(
                checkedThumbColor   = colors.accentText,
                checkedTrackColor   = colors.accent,
                uncheckedThumbColor = colors.accentText,
                uncheckedTrackColor = colors.divider,
            ),
        )
    }
}

// ── Dropdown Row ──────────────────────────────────────────────────────────────

@Composable
private fun SettingsSelectRow(label: String, options: List<String>) {
    val colors = KbTheme.colors
    var selected by remember { mutableStateOf(options.first()) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(colors.keyBg)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(text = label, style = KbType.tileText, color = colors.keyText)

        // Simple pill selector cycling through options
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(colors.specialBg)
                .padding(horizontal = 12.dp, vertical = 8.dp),
        ) {
            Text(text = selected, style = KbType.tileSub, color = colors.keyText)
        }
    }
}
