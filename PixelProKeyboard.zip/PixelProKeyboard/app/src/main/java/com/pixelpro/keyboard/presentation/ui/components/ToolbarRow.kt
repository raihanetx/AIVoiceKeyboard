package com.pixelpro.keyboard.presentation.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.pixelpro.keyboard.presentation.theme.KbTheme

// ── Toolbar ───────────────────────────────────────────────────────────────────

@Composable
fun ToolbarRow(
    onEmojiClick    : () -> Unit,
    onClipClick     : () -> Unit,
    onCredClick     : () -> Unit,
    onLangClick     : () -> Unit,
    onSettingsClick : () -> Unit,
    onVoiceClick    : () -> Unit,
    modifier        : Modifier = Modifier,
) {
    val colors = KbTheme.colors

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(44.dp)
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        ToolbarButton(iconRes = ToolbarIcons.Emoji,    onClick = onEmojiClick)
        ToolbarButton(iconRes = ToolbarIcons.Clip,     onClick = onClipClick)
        ToolbarButton(iconRes = ToolbarIcons.Key,      onClick = onCredClick)
        ToolbarButton(iconRes = ToolbarIcons.Globe,    onClick = onLangClick)
        ToolbarButton(iconRes = ToolbarIcons.Settings, onClick = onSettingsClick)
        ToolbarButton(iconRes = ToolbarIcons.Mic,      onClick = onVoiceClick)
    }
}

@Composable
private fun ToolbarButton(
    iconRes : ImageVector,
    onClick : () -> Unit,
) {
    val colors = KbTheme.colors
    val interactionSource = remember { MutableInteractionSource() }

    Box(
        modifier = Modifier
            .size(width = 44.dp, height = 40.dp)
            .clip(RoundedCornerShape(8.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = rememberRipple(color = colors.ripple),
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = iconRes,
            contentDescription = null,
            tint = colors.keyIcon,
            modifier = Modifier.size(22.dp),
        )
    }
}

// ── Icon aliases (mapped to Material Icons) ───────────────────────────────────

private object ToolbarIcons {
    val Emoji    get() = androidx.compose.material.icons.Icons.Outlined.EmojiEmotions
    val Clip     get() = androidx.compose.material.icons.Icons.Outlined.ContentPaste
    val Key      get() = androidx.compose.material.icons.Icons.Outlined.Key
    val Globe    get() = androidx.compose.material.icons.Icons.Outlined.Language
    val Settings get() = androidx.compose.material.icons.Icons.Outlined.Settings
    val Mic      get() = androidx.compose.material.icons.Icons.Outlined.Mic
}
