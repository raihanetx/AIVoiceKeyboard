package com.pixelpro.keyboard.domain.usecase

import com.pixelpro.keyboard.domain.model.ClipboardEntry
import com.pixelpro.keyboard.domain.model.CredentialEntry
import com.pixelpro.keyboard.domain.model.SuggestionResult
import com.pixelpro.keyboard.domain.repository.ClipboardRepository
import com.pixelpro.keyboard.domain.repository.CredentialRepository
import com.pixelpro.keyboard.domain.repository.SuggestionRepository
import kotlinx.coroutines.flow.Flow

class GetSuggestionsUseCase(private val repo: SuggestionRepository) {
    operator fun invoke(bufferText: String): SuggestionResult =
        repo.getSuggestions(bufferText)
}

class GetClipboardItemsUseCase(private val repo: ClipboardRepository) {
    operator fun invoke(): Flow<List<ClipboardEntry>> = repo.getClipboardItems()
}

class GetCredentialsUseCase(private val repo: CredentialRepository) {
    operator fun invoke(): Flow<List<CredentialEntry>> = repo.getCredentials()
}

class SaveToCredentialsUseCase(
    private val clipRepo: ClipboardRepository,
    private val credRepo: CredentialRepository,
) {
    suspend operator fun invoke(clipEntry: ClipboardEntry) {
        clipRepo.removeItem(clipEntry.id)
        credRepo.addCredential(
            CredentialEntry(
                id = clipEntry.id,
                text = clipEntry.text,
                label = "Saved Item",
            )
        )
    }
}

class DeleteClipboardItemUseCase(private val repo: ClipboardRepository) {
    suspend operator fun invoke(id: String) = repo.removeItem(id)
}
