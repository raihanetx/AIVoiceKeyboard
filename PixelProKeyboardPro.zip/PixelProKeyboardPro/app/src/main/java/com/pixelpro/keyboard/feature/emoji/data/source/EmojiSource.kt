package com.pixelpro.keyboard.feature.emoji.data.source

/** Complete emoji list, mirroring the HTML source exactly. */
object EmojiSource {
    val emojis: List<String> = listOf(
        "😀","😃","😄","😁","😅","😂","🤣","😊","😇","🙂","🙃","😉","😌",
        "😍","🥰","😘","😜","😎","😭","😡","🐶","🐱","🐭","🐹","🐰","🦊",
        "🐻","🐼","🐨","🐯","🦁","🐮","🐷","🐸","🐵","🍏","🍎","🍐","🍊",
        "🍋","🍌","🍉","🍇","🍓","🍈","🍒","🍑","🥭","🍍","🥥","⚽","🏀",
        "🏈","⚾","🥎","🎾","🏐","🏉","🎱","🪀","🏓","🏸","🏒","🏑",
    )
}
