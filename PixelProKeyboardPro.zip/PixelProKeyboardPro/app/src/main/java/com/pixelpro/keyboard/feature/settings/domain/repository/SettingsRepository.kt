package com.pixelpro.keyboard.feature.settings.domain.repository

import com.pixelpro.keyboard.feature.settings.domain.model.SettingsState
import kotlinx.coroutines.flow.Flow

interface SettingsRepository {
    fun getSettings(): Flow<SettingsState>
    suspend fun updateSettings(settings: SettingsState)
}
