package com.pixelpro.keyboard.core.di

import com.pixelpro.keyboard.feature.clipboard.data.repository.ClipboardRepositoryImpl
import com.pixelpro.keyboard.feature.clipboard.domain.repository.ClipboardRepository
import com.pixelpro.keyboard.feature.clipboard.domain.usecase.GetClipboardItemsUseCase
import com.pixelpro.keyboard.feature.clipboard.domain.usecase.SaveToCredentialsUseCase
import com.pixelpro.keyboard.feature.credentials.data.repository.CredentialRepositoryImpl
import com.pixelpro.keyboard.feature.credentials.domain.repository.CredentialRepository
import com.pixelpro.keyboard.feature.credentials.domain.usecase.GetCredentialsUseCase
import com.pixelpro.keyboard.feature.keyboard.data.repository.SuggestionRepositoryImpl
import com.pixelpro.keyboard.feature.keyboard.domain.repository.SuggestionRepository
import com.pixelpro.keyboard.feature.keyboard.domain.usecase.GetSuggestionsUseCase
import com.pixelpro.keyboard.feature.keyboard.ui.KeyboardViewModel
import com.pixelpro.keyboard.feature.settings.data.repository.SettingsRepositoryImpl
import com.pixelpro.keyboard.feature.settings.domain.repository.SettingsRepository

/**
 * Manual dependency injection container.
 *
 * All repositories are singletons — created once and reused.
 * To migrate to Hilt, simply annotate each impl with @Singleton
 * and replace [provideKeyboardViewModel] with a @HiltViewModel.
 *
 * Dependency graph:
 *   SettingsRepository  (singleton)
 *   SuggestionRepository (singleton)
 *   ClipboardRepository  (singleton)
 *   CredentialRepository (singleton)
 *       └─ SaveToCredentialsUseCase (needs both clipboard + credential repos)
 *   KeyboardViewModel (new instance per IME session)
 */
object AppModule {

    // ── Repositories (lazy singletons) ────────────────────────────────────────

    val settingsRepository: SettingsRepository by lazy {
        SettingsRepositoryImpl()
    }

    val suggestionRepository: SuggestionRepository by lazy {
        SuggestionRepositoryImpl()
    }

    val clipboardRepository: ClipboardRepository by lazy {
        ClipboardRepositoryImpl()
    }

    val credentialRepository: CredentialRepository by lazy {
        CredentialRepositoryImpl()
    }

    // ── Use Cases (lazy, depend on repositories above) ────────────────────────

    private val getSuggestionsUseCase by lazy {
        GetSuggestionsUseCase(suggestionRepository)
    }

    private val getClipboardItemsUseCase by lazy {
        GetClipboardItemsUseCase(clipboardRepository)
    }

    private val getCredentialsUseCase by lazy {
        GetCredentialsUseCase(credentialRepository)
    }

    private val saveToCredentialsUseCase by lazy {
        SaveToCredentialsUseCase(clipboardRepository, credentialRepository)
    }

    // ── ViewModel factory ─────────────────────────────────────────────────────

    /** Call this once from [com.pixelpro.keyboard.PixelProIME] to get the ViewModel. */
    fun provideKeyboardViewModel(): KeyboardViewModel = KeyboardViewModel(
        getSuggestionsUseCase    = getSuggestionsUseCase,
        getClipboardItemsUseCase = getClipboardItemsUseCase,
        getCredentialsUseCase    = getCredentialsUseCase,
        saveToCredentialsUseCase = saveToCredentialsUseCase,
    )
}
